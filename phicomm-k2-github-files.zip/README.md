# Phicomm K2 — experimental OpenWrt build

This project uses OpenWrt 23.05.5 ImageBuilder to produce a **test image** for the standard Phicomm K2 (PSG1218, MT7620A, 8 MB flash / 64 MB RAM).

## Run the build
1. Upload these files to your repository, preserving the directory structure.
2. Open **Actions** → **Build Phicomm K2 OpenWrt** → **Run workflow**.
3. When the run succeeds, download the `phicomm-k2-test-firmware` artifact.

## Important
- The workflow targets `phicomm_k2-v22.5`, for K2 hardware revision v22.5 or newer only.
- K2 v22.4 or older needs a different profile. K2G, K2P, and K2C are different devices.
- This is a baseline ImageBuilder build, not a driver, switch, DSA, partition-table, or bootloader modification.
- It does not guarantee a fix for Wi-Fi hangs or internet dropouts.
- The first-boot defaults set hostname `AL-YAHYAWI-K2` and disable `dnsmasq`, `firewall`, and `odhcpd` for AP/bridge testing. DHCP must be supplied by an upstream router.
- Do not flash unless the exact model/revision and recovery method are confirmed. Do not change bootloader or partitions with this workflow.

## Brand
اليحيوي للتجارة ومستلزمات الشبكات
